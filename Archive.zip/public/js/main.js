/* eslint-env jquery, browser */
$(document).ready(() => {

  // Place JavaScript code here...
  $('#loginbtn').click(() => {
    $('#loginBtn').submit(); 
  });
});
